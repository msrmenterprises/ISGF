import React, {useState} from "react";
import OwlCarousel from "react-owl-carousel";
import "owl.carousel/dist/assets/owl.carousel.css";
import "owl.carousel/dist/assets/owl.theme.default.css";
import { NavLink, Link } from "react-router-dom";
import { useForm } from 'react-hook-form';
import axios from "axios";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Welcome from "./Welcome.jsx";
const GLOBAL = require('../../commonConstants.js');

const banner = GLOBAL.BASE_URL+"banners";
const assetUrl = GLOBAL.assetUrl;
const achievements = GLOBAL.BASE_URL+"achievements_home";
const domainExpert = GLOBAL.BASE_URL+"domainExpert_home";
const functionalExpertise = GLOBAL.BASE_URL+"functionalExpertise_home";
const news = GLOBAL.BASE_URL+"news_home";
const whitepapers = GLOBAL.BASE_URL+"white-paper-tech-report-home";
const whiteUrl = GLOBAL.BASE_URL+"white-paper-tech-report?id=2";
const WhatsNew_program = GLOBAL.BASE_URL+"events_home";
const WhatsNew_member = GLOBAL.BASE_URL+"members_home";
const WhatsNew_focus = GLOBAL.BASE_URL+"focus-areas-home";
const memberCategory = GLOBAL.BASE_URL+"memberCategory";
const homeslider = {
  margin: 30,
  responsiveClass: true,
  loop: true,
  nav: true,
  autoplay: true,
  navText: [
    "<i class='fa fa-long-arrow-left'></i>",
    "<i class='fa fa-long-arrow-right'></i>",
  ],
  smartSpeed: 1000,
  responsive: {
    0: {
      items: 1,
    },
    400: {
      items: 1,
    },
    600: {
      items: 1,
    },
    700: {
      items: 1,
    },
    1000: {
      items: 1,
    },
  },
};

const whatnew = {
  margin: 30,
  responsiveClass: true,
  loop: true,
  nav: true,
  autoplay: false,

  smartSpeed: 1000,
  responsive: {
    0: {
      items: 1,
    },
    400: {
      items: 1,
    },
    600: {
      items: 2,
    },
    700: {
      items: 2,
    },
    1000: {
      items: 3,
    },
  },
};

const members = {
  margin: 30,
  responsiveClass: true,
  loop: true,
  nav: true,
  autoplay: true,
  smartSpeed: 1000,
  responsive: {
    0: {
      items: 2,
    },
    400: {
      items: 2,
    },
    600: {
      items: 3,
    },
    700: {
      items: 4,
    },
    1000: {
      items: 5,
    },
  },
};
const Home = () => {
  const [email, setEmail] = React.useState("");
  const {register,handleSubmit,formState:{errors}} = useForm();
  const [success, setSuccess] = React.useState("");
  
  // console.log(success);
function saveData() {

        axios({
            method: "post",
            url: GLOBAL.BASE_URL+"bulletin_form",
            data: {email},
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
            },
            
        })
            .then(function (response) {
              setSuccess(response);
              toast('Subscribed Successfully');
              setEmail("");
            })
            .catch(function (response) {
                //handle error
                console.log(response);
            });

    }
  const onSubmit = (data) =>{
          saveData();
  }
  const [getBanner, setBanner] = React.useState(null);
  const [getAchievements, setAchievements] = React.useState(null);
  const [getDomain, setDomain] = React.useState(null);
  const [getFunction, setFunction] = React.useState(null);
  const [getNews, setNews] = React.useState(null);
  const [getWhitePapers, setWhitePapers] = React.useState(null);
  const [getLatestWhitePapers, setLatestWhitePapers] = React.useState(null);
  const [getWhatsNewMember, setWhatsNew_member] = React.useState(null);
  const [getWhatsWhatsNew_focus, setWhatsWhatsNew_focus] = React.useState(null);
  const [getWhatsWhatsNew_program, setWhatsWhatsNew_program] = React.useState(null);
  const [getMemberCategory, setMemberCategory] = React.useState(null);
  React.useEffect(() => {
    axios.get(WhatsNew_member).then((response) => {
      setWhatsNew_member(response.data);
     });
    axios.get(WhatsNew_focus).then((response) => {
    setWhatsWhatsNew_focus(response.data);
     });
    axios.get(WhatsNew_program).then((response) => {
    setWhatsWhatsNew_program(response.data);
     });
    axios.get(whiteUrl).then((response) => {
    setWhitePapers(response.data);
     });
    axios.get(whitepapers).then((response) => {
    setLatestWhitePapers(response.data);
     });
    axios.get(banner).then((response) => {
      setBanner(response.data);
     });
    axios.get(achievements).then((response) => {
    setAchievements(response.data);
     });
    axios.get(domainExpert).then((response) => {
    setDomain(response.data);
     });
    axios.get(functionalExpertise).then((response) => {
    setFunction(response.data);
     });
    axios.get(news).then((response) => {
    setNews(response.data);
     });
    axios.get(memberCategory).then((response) => {
    setMemberCategory(response.data);
     });
   },[]);
   if (!getBanner) return null;
  if (!getAchievements) return null;
  if (!getDomain) return null;
  if (!getFunction) return null;
  if (!getNews) return null;
  if (!getWhatsNewMember) return null;
  if (!getWhatsWhatsNew_focus) return null;
  if (!getWhatsWhatsNew_program) return null;
  if (!getMemberCategory) return null;
  
  

  return (
    <>
      {/* <Media /> */}
      <ToastContainer />
      
      {/* <Welcome/> */}
      
      <div className="main-banner">
        <div className="swiper-container main-banner">
          <div className="swiper-wrapper">
            <OwlCarousel
              className="owl-theme"
              loop
              margin={10}
              nav
              {...homeslider}
            >
                   {(getBanner) && getBanner.map((data,index)=>(
              <div
                className="item swiper-slide"
                style={{
                  backgroundImage: `url(${assetUrl + "/public/banner_img/" + data.image})`,
                }}
              >
                <div className="container">
                  <h2>
                    {data.heading}
                  </h2>
                  <p>{data.sub_heading}</p>
                  <a href={data.link} exact className="btn btn-orange">
                    Read More
                  </a>
                </div>
              </div>
                  ))}
             
            </OwlCarousel>
          </div>
        </div>
      </div>
      <div className="whats-new sec-padd">
        <div className="container">
          <div className="heading mb-3">
            <h2>What's New</h2>
            {/* <NavLink to="/" className="btn btn-orange">
              View All
            </NavLink> */}
          </div>
          <div className="row gx-3 gy-3">
            <div className="col-md-12">
              <div className="home-demo">
                <OwlCarousel
                  className="owl-theme"
                  loop
                  margin={10}
                  nav
                  {...whatnew}
                >
                  <div className="item">
                    <div className="box what-min first_two_member_none">
                      <div className="box-head">ISGF Member Updates</div>
                      <div className="box-body">
                         {(getWhatsNewMember) && getWhatsNewMember.map((data,index)=>(
                        <p>
                          <i className="fa fa-check"></i> 
                          {data.title}
                        </p>
                         ))}
                      </div>
                      <div className="text-center mb-2 click-here">
                      <NavLink to="/members-list" className="btn btn-orange">
                        Read More
                      </NavLink>
                      </div>
                    </div>
                  </div>
                  <div className="item">
                    <div className="box what-min">
                      <div className="box-head">ISGF New Focus Areas </div>
                      <div className="box-body">
                        {(getWhatsWhatsNew_focus) && getWhatsWhatsNew_focus.map((data,index)=>(
                        <p>
                          <i className="fa fa-check"></i> 
                          {data.title}
                        </p>
                         ))}
                      </div>
                      <div className="text-center mb-2 click-here">
                      <NavLink to="/isgf-focus-areas" className="btn btn-orange">
                        Read More
                      </NavLink>
                        {/* <NavLink to="/isgf-focus-areas" class="btn btn-orange"> Read More</NavLink> */}
                      </div>
                    </div>
                  </div>
                  <div className="item">
                    <div className="box what-min">
                      <div className="box-head">ISGF Programs and Public Notices</div>
                      <div className="box-body">
                        <h5>ISGF Programs</h5>
                        {(getWhatsWhatsNew_program) && getWhatsWhatsNew_program.map((data,index)=>(
                        <p>
                          {/* <i className="fa fa-check"></i>  */}
                          {/* {data.title} */}
                          {((data.public_notice == 0 ))  ? <> <i className="fa fa-check"></i> {data.title} </>: <> </>}
                        </p>
                        
                         ))}
                         
                         <h5>Public Notice by ISGF</h5>
                         
                            {(getWhatsWhatsNew_program) && getWhatsWhatsNew_program.map((data,index)=>(
                            
                            <p>
                               {((data.public_notice == 1 ))  ? <> <i className="fa fa-check"></i> {data.title} </>: <> </>}
                              
                            </p>
                            
                            ))}

                    
                         
                      </div>
                      <div className="text-center mb-2 click-here">
                      <NavLink to="/event-calendar" className="btn btn-orange">
                        Read More
                      </NavLink>
                        {/* <NavLink to="/isgf-focus-areas" class="btn btn-orange"> Read More</NavLink> */}
                      </div>
                    </div>
                  </div>
                </OwlCarousel>
                
              </div>
            </div>
          </div>
        </div>
      </div>
      <div
        className="industry-news sec-padd"
        style={{
          backgroundImage: `url(${
            process.env.PUBLIC_URL + "/images/news-bg.png"
          })`,
        }}
      >
        <div className="container">
          <div className="heading mb-3">
            <h2>Industry News</h2>
            <NavLink to="/smart-grid-news" className="btn btn-white view-all">
              View All News
            </NavLink>
          </div> 
           
          <div className="row g-4">
            {(getNews) && getNews.map((data,index)=>(
            <div className="col-md-4 col-sm-4">
                  {((index <= 8 ))  ? <>

                  <div className="home-n">
                    <div className="row g-4">
                      <div className="col-5">
                        <img src={assetUrl + "/public/news_img/" + data.image} alt="pic" width="100%" />
                      </div>
                      <div className="col-7">
                        <div className="content">
                          <div className="name">
                            {(data.title)}
                          </div>
                          <Link className="link" to={"../news-detail/" + data.slug}>View</Link>
                        </div>
                      </div>
                    </div>
                  </div>
             </>: <> </>}
              </div>
              ))}
          </div>
          
        </div>
      </div>
      <div className="contibute sec-padd">
        <div className="container">
          <div className="heading mb-3">
            <h2>ISGF Contributions and Achievements</h2>
          </div>
          <div className="row gx-3 gy-3">
            <div className="col-md-4">
              <div
                className="box green"
                style={{
                  backgroundImage: `url(${
                    process.env.PUBLIC_URL + "/images/contri-box1.jpg"
                  })`,
                }}
              >
                <div className="box-head">Achievements</div>
                <div className="box-body">
                  {(getAchievements) && getAchievements.map((data,index)=>(
                  <div>
                  {((index <= 5 ))  ? <>
                  <p>{data.title}</p>
                  </>: <> </>}
                  </div>
                  ))}
                </div>
                <div className="btn-pos">
                    <NavLink
                      to="/achievements"
                      className="btn btn-white"
                    >
                      Read More
                    </NavLink>
                  </div>
              </div>
            </div>
            <div className="col-md-4">
              <div
                className="box orange"
                style={{
                  backgroundImage: `url(${
                    process.env.PUBLIC_URL + "/images/contri-box2.jpg"
                  })`,
                }}
              >
                <div className="box-head">Domain Expertise</div>
                
                <div className="box-body">
                  {(getDomain) && getDomain.map((data,index)=>(
                  <div>
                  {((index <= 5 ))  ? <>
                  <p>{data.title}</p>
                  </>: <> </>}
                  </div>
                  ))}
                   
                </div>
                <div className="btn-pos">
                    <NavLink to="/domain-of-expertise" className="btn btn-white">
                      Read More
                    </NavLink>
                  </div>
              
              </div>
            </div>
            <div className="col-md-4">
              <div
                className="box blue"
                style={{
                  backgroundImage: `url(${
                    process.env.PUBLIC_URL + "/images/contri-box3.jpg"
                  })`,
                }}
              >
                <div className="box-head">Functional Expertise</div>
                <div className="box-body">
                  {(getFunction) && getFunction.map((data,index)=>(
                  <div>
                  {((index <= 5 ))  ? <>
                  <p>{data.title}</p>
                  </>: <> </>}
                  </div>
                  ))}
                </div>
                <div className="btn-pos">
                <NavLink exact to="/functional-expertise" className="btn btn-white">
                      Read More
                    </NavLink>
                  </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="latest">
        <div className="container">
          <div className="row gx-0 gy-3">
            <div className="col-md-8">
              <div
                className="box-main"
                style={{
                  backgroundImage: `url(${
                    process.env.PUBLIC_URL + "/images/latest-bg-1.jpg"
                  })`,
                }}
              >
                <div className="row gx-0 gy-3">
                  <div className="col-md-6">
                    <div className="box">
                      <div className="heading mb-3">
                        <h2>Latest ISGF Reports</h2>
                        <NavLink
                          to="/white-papers-technical-reports"
                          className="btn btn-white"
                        >
                          View All
                        </NavLink>
                      </div>
                      {(getLatestWhitePapers) && getLatestWhitePapers.map((data,index)=>(
                      <div className="book">
                      {((index <= 2 ) && (data.page_content_type !== 2 ))  ? <>
                        <div className="row">
                          <div className="col-3">
                            <img src={assetUrl + "/public/banner_img/" + data.image} alt="" />
                          </div>
                          <div className="col-9">
                            <h5>
                              <a className="latest-white-a" href={assetUrl + "/public/banner_img/" + data.document} target="_blank">{data.title}</a>
                            </h5>
                            {/* <NavLink to={data.slug} className="btn btn-white">
                              Read More
                            </NavLink> */}
                          </div>
                        </div>
                        </>: <> </>}
                      </div>
                      ))}
                       
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="box">
                      <div className="heading mb-3">
                        <h2>ISGF Whitepapers</h2>
                        <NavLink
                          to="/white-papers-technical-reports"
                          className="btn btn-white"
                        >
                          View All
                        </NavLink>
                      </div>
                      {(getWhitePapers) && getWhitePapers.map((data,index)=>(
                      <div className="book">
                      {((index <= 2 ) && (data.page_content_type == 2 ))  ? <>
                        <div className="row">
                          <div className="col-3">
                            <img src={assetUrl + "/public/banner_img/" + data.image} alt="" />
                          </div>
                          <div className="col-9">
                            <h5>
                            
                             <a className="latest-white-a" href={assetUrl + "/public/banner_img/" + data.document} target="_blank">
                             {data.title}</a>
                            </h5>
                            {/* <NavLink to="#" className="btn btn-white">
                              Read More
                            </NavLink> */}
                          </div>
                        </div>
                        </>: <> </>}
                      </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div
                className="green-box"
                style={{
                  backgroundImage: `url(${
                    process.env.PUBLIC_URL + "/images/latest-bg-2.jpg"
                  })`,
                }}
              >
                <div className="row gx-0 gy-3">
                  <div className="col-md-12">
                    <div className="box">
                      <div className="heading mb-3">
                        <h2>Smart Grid Bulletin</h2>
                        <NavLink to="/smart-grid-bulletin" className="btn btn-white view-all smart-grid-bulletin-right">
                          View All
                        </NavLink>
                      </div>
                      <div className="book">
                        <div className="row">
                          <div className="col-4">
                            <img src={`${process.env.PUBLIC_URL}/images/book5.jpg`} alt="" />
                          </div>
                          <div className="col-8">
                            <h5>July 2022</h5>
                            <a
                              href="https://cruxcreativedemo2.com/isgf-final/public/attachment/Newsletter.pdf" target="_blank"
                              className="btn btn-white white-btn"
                            >
                              Read More
                            </a>
                          </div>
                        </div>
                      </div>
                      <div className="book">
                        <div className="heading">
                          <h2>ISGF Bulletin Subscription</h2>
                          <p>
                            Signup for your monthly copy of ISGF Smart Grid
                            Bulletin for all the latest news from ISGF and
                            special announcements!
                          </p>
                        </div>
                        <form action="" onSubmit={handleSubmit(onSubmit)}>
                        <div className="input-group mt-3">
                          <input
                            type="text"
                            className="form-control"
                            placeholder="Email address"
                            value={email}
                            {...register('email',{required:"Email is Required",pattern: /^[a-zA-Z0-9]+@(?:[a-zA-Z0-9]+\.)+[A-Za-z]+$/
})}                          onChange={(e) => setEmail(e.target.value)}
                          />
                          <div className="input-group-append">
                              <button type="submit" className="email-btn btn-orange">
                                Subscribe
                              </button>
                            </div>
                        </div>
                        {errors.email && (<small className="text-white">Invalid Email Address*</small>)} 
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="member-logo sec-padd">
        <div className="container">
            <div className="heading mb-3">
                <h2>ISGF Members</h2>
                <NavLink to="members-list" className="btn btn-white">View All</NavLink>
            </div>
            <div className="swiper-container logo-m">
                <div className="swiper-wrapper">
                <OwlCarousel className='owl-theme' loop margin={10} nav {...members}>

                
                    {(getMemberCategory) && getMemberCategory.map((data,index)=>(
                    <div className="item ">
                       <a href={data.link} target="_blank"> 
                          <img src={assetUrl + "/public/Category_img/" + data.image}/>
                        </a>
                       <h6>{data.title}</h6>
                    </div>
                    ))}
                    
                    </OwlCarousel>
                </div>
               
            </div>
        </div>
    </div>
    <div className="b-member sec-padd">
        <div className="container">
            <div className="heading mb-3">
                <h2>Become a Member</h2>
            </div>
            <div className="row">
                <div className="col-md-8">
                    <p>ISGF members are from the ministries, government institutions, regulatory bodies, utilities, industry,
                        non-profit organizations, educational and research entities and students from renowned institutions.</p>
                </div>
                <div className="col-md-4">
                    <NavLink to="/become-a-member" className="btn btn-green">Know More About ISGF Membership</NavLink>
                </div>
            </div>
        </div>
    </div>
    </>
  );
};

export default Home;
